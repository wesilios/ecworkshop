@extends('layouts.adminapp')

@section('content')
	<section class="content-header">
		<h1>
			Tất cả bài viết
			<small></small>
		</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li class="active">Tất cả bài viết</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
        <div class="row">
            <div class="col-xs-12">
				@php
            		$i = 1;
				@endphp
            	@if(session('status'))
            	<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-info"></i> Alert!</h4>
                    {{ session('status') }}
                </div>
                @endif
                @if(session('delete'))
            	<div class="alert alert-warning alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                    {{ session('delete') }}
                </div>
                @endif
				<div class="box">
			        <div class="box-header">
			          	<h3 class="box-title">Danh sách bài viết</h3>
			        </div><!-- /.box-header -->
	       			<div class="box-body table-responsive no-padding">
	          			<table class="table table-hover">
          					<tr>
								<th>#Id</th>
								<th>Tiêu đề</th>
								<th>Nội dung</th>
								<th>Danh mục bài viết</th>
								<th>Thẻ bài viết</th>
								<th>Ngày tạo</th>
								<th>Đăng bởi</th>
								<th></th>
		                    </tr>
		                    <tr>
		                    	@if($articles->count() > 0)
									@foreach($articles as $article)
										<tr>
											<td>{{ $i }}</td>
											<td>{{ $article->title }}</td>
											<td>{!! str_limit($article->content, 30) !!}</td>
											<td>{{ $article->category->name }}</td>
											<td>
												@foreach($article->tags as $tag)
													<span class="label label-info">{{ $tag->name }}</span>
												@endforeach
											</td>
											<td>{{ date("F jS, Y", strtotime($article->created_at)) }}</td>
											<td>{{ $article->admin->name }}</th>
											<td>
												<a href="" class="btn btn-default btn-sm">Xem</a>
												<a href="{{ route('articles.edit',[$article->id]) }}" class="btn btn-default btn-sm">Sửa</a>
											</td>
										</tr>
										@php
						            		$i++;
										@endphp
									@endforeach
								@else
								<td colspan="9" style="text-align:center">Chưa có bài viết nào</td>
		                    	@endif
		                    </tr>
		                </table>
		                <div class="text-center">
		                	{!! $articles->links()!!}
		                </div>
		            </div>
		        </div>
		        <a href="{{ route('articles.create') }}" class="btn btn-info"><i class="fa fa-plus"></i> Bài viết mới</a>
            </div>
		</div>
	</section>
@endsection
