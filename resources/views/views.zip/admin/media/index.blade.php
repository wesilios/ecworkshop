@extends('layouts.adminapp')

@section('content')
	<section class="content-header">
		<h1>
			Media
			<button class="btn bg-maroon btn-xs media-addnew">Add new</button>
		</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li class="active">Media</li>
		</ol>
	</section>
	<section class="content">
        <div class="row">
        	<div class="col-md-12">
        		<div class="uploadZone">
        			<div class="fileSelectZone">
	        			<a class="closeZone pull-right"><i class="fa fa-close fa-2x"></i></a>
	        			<div class="upload-ui">
	        				<h2>Drop files anywhere to upload</h2>
							<p>or</p>
							<button class="btn btn-default selectFile">Select Files</button>
	        			</div>
	        		</div>
        		</div>
        	</div>
        	<div class="col-md-12">
        		@if(session('error'))
            	<div class="alert alert-warning alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                    {{ session('error') }}
                </div>
                @endif
                @if(session('delete'))
            	<div class="alert alert-warning alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                    {{ session('delete') }}
                </div>
                @endif
                @if(session('status'))
            	<div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-info"></i> Alert!</h4>
                    {{ session('status') }}
                </div>
                @endif
                @if ($errors->has('medias'))
	                <span class="help-block">
	                    <strong>{{ $errors->first('medias') }}</strong>
	                </span>
	            @endif
				<div class="box box-hidden">
					<div class="box-body">
						<div class="form-hidden">
		    				{!! Form::open(['method'=>'POST', 'action'=>"AdminMediaController@create" ,'files'=>true]) !!}
								{!! Form::file('medias[]', array('multiple'=>true,'id'=>'form-file-hidden')) !!}
								<div class="form-group">
									<button class="btn btn-default selectFile">Select files</button>
									{!! Form::submit('Upload', ['class'=>'btn btn-info']) !!}
								</div>
			    			{!! Form::close() !!}
		    			</div>
		    			<div id="preview-image">

		    			</div>
					</div>
				</div>
        	</div>
        </div>
        <div class="row">
        	<div class="col-md-12">
        		<div class="box box-solid">
        			<div class="box-header">
        				<h3 class="box-title">Media gallery</h3>
        			</div>
        			<div class="box-body">
        				<div class="displayImages">
		        			@foreach($medias as $media)
							<div class="col-sm-2">
								<div class="thumbnails_img" style="background-image:url('{{ asset($media->url) }}')">
									<div class="caption">
										<div class="caption-content">
											<a href="#" data-toggle="modal" data-target="#new_modal{{ $media->id }}">
					                            <div class="btn btn-info">
					                              	<i class="fa fa-eye"></i>
					                            </div>
					                        </a>
										</div>
									</div>
								</div>
							</div>
							@endforeach
		        		</div>
        			</div>
        			<div class="box-footer">
        				<div class="text-center">
		                	{!! $medias->links()!!}
		                </div>
        			</div>
        		</div>
        	</div>

       	</div>
	</section>
	@foreach($medias as $media)
		<div class="example-modal">
		  	<div class="modal fade item_modal" id="new_modal{{ $media->id }}" role="dialog">
		    	<div class="modal-dialog modal-dialog-95" style="border-top:5px solid #0097bc; border-radius:4px">
		      		<div class="modal-content">
		          		<div class="modal-header">
		            		<div>
		            			<span>Media Details</span>
		              			<div class="pull-right">
		                			<button type="button" class="btn-custom btn-default" data-dismiss="modal">
		                				<i class="fa fa-close"></i>
		                			</button>
		              			</div>
		            		</div>
		          		</div>
		          		<div class="modal-body">
		            		<div class="row">
		              			<div class="col-sm-8">
			                		<div style="min-height:600px; width:100%; padding-bottom:15px">
			                  			<img src="{{ asset($media->url) }}" alt="" class="img-responsive">
			              			</div>
			            		</div>
			            		<div class="col-sm-4 media-info">
			            			<div class="filename">
			            				<strong>File name: </strong> {{ $media->file_name }}
			            			</div>
			            			<div class="filetype">
			            				<strong>File type: </strong> {{ $media->type }}
			            			</div>
			            			<div class="created_at">
			            				<strong>Uploaded date: </strong> {{ $media->created_at->diffForHumans() }}
			            			</div>
			            			<div class="updated_at">
			            				<strong>Updated date: </strong> {{ $media->updated_at->diffForHumans() }}
			            			</div>
			            			<div class="uploaded by">
			            				<strong>Uploaded by: </strong> {{ $media->admin->name }}
			            			</div>
			            			<hr>
			            			{!! Form::open(['method'=>'PUT', 'action'=>['AdminMediaController@update', $media->id], 'class'=>'form-horizontal']) !!}
										<div class="form-group {{ $errors->has('url') ? ' has-error' : '' }}">
			                    			{!! Form::label('url', 'Url:', ['class' => 'col-sm-4 control-label'] ) !!}
					                      	<div class="col-sm-8">
												{!! Form::text('url', asset($media->url), ['class'=>'form-control', 'readonly']) !!}
					                      		@if ($errors->has('url'))
									                <span class="help-block">
									                    <strong>{{ $errors->first('url') }}</strong>
									                </span>
									            @endif
					                      	</div>
					                    </div>
					                    <div class="form-group {{ $errors->has('title') ? ' has-error' : '' }}">
			                    			{!! Form::label('title', 'Title:', ['class' => 'col-sm-4 control-label'] ) !!}
					                      	<div class="col-sm-8">
												{!! Form::text('title', $media->title, ['class'=>'form-control']) !!}
					                      		@if ($errors->has('title'))
									                <span class="help-block">
									                    <strong>{{ $errors->first('title') }}</strong>
									                </span>
									            @endif
					                      	</div>
					                    </div>
					                    <div class="form-group {{ $errors->has('caption') ? ' has-error' : '' }}">
			                    			{!! Form::label('caption', 'Caption:', ['class' => 'col-sm-4 control-label'] ) !!}
					                      	<div class="col-sm-8">
												{!! Form::textarea('caption', $media->caption, ['class'=>'form-control', 'rows'=>'3']) !!}
					                      		
					                      	</div>
					                    </div>
					                    <div class="form-group {{ $errors->has('alt_text') ? ' has-error' : '' }}">
			                    			{!! Form::label('alt_text', 'Alt text:', ['class' => 'col-sm-4 control-label'] ) !!}
					                      	<div class="col-sm-8">
												{!! Form::text('alt_text', $media->alt_text, ['class'=>'form-control']) !!}
					                      	</div>
					                    </div>
					                    <div class="form-group {{ $errors->has('description') ? ' has-error' : '' }}">
			                    			{!! Form::label('description', 'Description:', ['class' => 'col-sm-4 control-label'] ) !!}
					                      	<div class="col-sm-8">
												{!! Form::textarea('description', $media->description, ['class'=>'form-control', 'rows'=>'3']) !!}
					                      	</div>
					                    </div>
					                <hr>
					                <ul>
					                	<li>{!! Form::submit('Lưu thay đổi', ['class'=>'btn-nothing']) !!}</li>
					                	<li>
					                		<a href="#" data-toggle="modal" data-target="#delete{{ $media->id }}">
					                            <div class="btn-danger"> Delete media</div>
					                        </a>
					                    </li>
					                </ul>
			            			{!! Form::close() !!}
			            		</div>
		        			</div>
		        		</div>
		      		</div><!-- /.modal-content -->
		    	</div><!-- /.modal -->
		  	</div> 
		</div><!-- /.example-modal -->
		<div class="example-modal">
		  	<div class="modal fade item_modal" id="delete{{ $media->id }}" role="dialog">
		    	<div class="modal-dialog delete-dialog" style="">
		      		<div class="modal-content">
		        		<div class="modal-body">
		         			<h5>Xóa hình này?</h5>
		        		</div>
		        		<div class="modal-footer">
		        			{!! Form::open(['method'=>'DELETE', 'action'=>['AdminMediaController@destroy', $media->id], 'class'=>'form-horizontal']) !!}
		        				<button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
								{!! Form::submit('Xóa', ['class'=>'btn btn-primary']) !!}
	            			{!! Form::close() !!}
		        		</div>
		      		</div>
		    	</div>
		 	</div>
		</div>
	@endforeach
@endsection

@section('extendscripts')
	
@endsection